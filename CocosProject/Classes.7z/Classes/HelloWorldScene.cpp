#include "HelloWorldScene.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

USING_NS_CC;

//using namespace cocostudio::timeline;



Scene* HelloWorld::createScene() {
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init() {
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() ) {
        return false;
    }

	this->numLeafs = 3;
	this->leafSpeed = 1.0f;


	visibleSize = Director::getInstance()->getVisibleSize();
	origin = Director::getInstance()->getVisibleOrigin();



	/////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program

    // add a "close" icon to exit the progress. it's an autorelease object
    auto closeItem = MenuItemImage::create(
                                           "CloseNormal.png",
                                           "CloseSelected.png",
                                           CC_CALLBACK_1(HelloWorld::menuCloseCallback, this));
    
	closeItem->setPosition(Vec2(origin.x + visibleSize.width - closeItem->getContentSize().width/2 ,
                                origin.y + closeItem->getContentSize().height/2));

    // create menu, it's an autorelease object
    auto menu = Menu::create(closeItem, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);





	// Event Listener
	listener = EventListenerTouchOneByOne::create();
	listener->onTouchBegan = CC_CALLBACK_2(HelloWorld::onTouchBegan, this);



	spriteLeaf = Sprite::create("Leefy-Happy.png");
	spriteLeaf->setPosition(this->getBoundingBox().getMidX(), this->getBoundingBox().getMidY());
	//spriteLeaf->setPosition(0, 0);
	spriteLeaf->setScale(0.5f);
	this->addChild(spriteLeaf, 0);
	this->scheduleUpdate();
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, spriteLeaf);








    
    /*auto rootNode = CSLoader::createNode("MainScene.csb");

    addChild(rootNode);

	OutputDebugString(TEXT("testing2"));

	CCSize winSize = CCDirector::sharedDirector()->getWinSize();

	CCSprite *target = CCSprite::create("Branch1.png", 
        CCRectMake(0,0,27,40) );

	Integer *target2 = CCSprite::getChildrenCount();


	target->setPosition( 
       ccp(winSize.width + (target->getContentSize().width/2), 
       10) );

	this->addChild(target);*/

    return true;
}

void HelloWorld::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}

void HelloWorld::update(float delta) {
	/*auto position = sprite4->getPosition();
	position.y -= 250 * delta;
	if (position.y  < 0 - (sprite4->getBoundingBox().size.width / 2))
		position.y = this->getBoundingBox().getMaxX() + sprite4->getBoundingBox().size.width / 2;
	sprite4->setPosition(position);*/
}

// Title goes in the middle of the screen and generally doesn't change
void HelloWorld::addLabelTitle(const std::string& lbl, float size)
{
	auto label = Label::createWithTTF(lbl, "fonts/Marker Felt.ttf", size);

	label->setPosition(Vec2(origin.x + visibleSize.width / 2,
		origin.y + visibleSize.height - label->getContentSize().height));
		
	this->addChild(label, 1);
}

void HelloWorld::addLabelText(const std::string& lbl, Vec2 pos, float size)
{
	/*lblCoins = Label::createWithTTF(lbl, "fonts/Marker Felt.ttf", size);

	lblCoins->setPosition(Vec2(pos.x + lblCoins->getContentSize().width,
		pos.y + visibleSize.height - lblCoins->getContentSize().height));

	this->addChild(lblCoins, 1);*/
}

void HelloWorld::addSimpleButton(const std::string& fileName, Vec2 pos, float scale)
{
	/*auto sprite = Sprite::create(fileName);
	sprite->setScale(scale);
	sprite->setPosition(Vec2(pos.x + sprite->getContentSize().width,
		pos.y + visibleSize.height - sprite->getContentSize().height));

	this->addChild(sprite, 1, kTagSprite5);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener->clone(), sprite);*/
}

bool HelloWorld::onTouchBegan(Touch* touch, Event* event)
{/*
	auto target = static_cast<Sprite*>(event->getCurrentTarget());

	//Get the position of the current point relative to the button
	Point locationInNode = target->convertToNodeSpace(touch->getLocation());
	Size s = target->getContentSize();
	Rect rect = Rect(0, 0, s.width, s.height);

	//Check the click area
	if (rect.containsPoint(locationInNode))
	{
		switch (target->getTag())
		{
		case kTagSprite1:
			log("Coin");
			this->coinsGot += 1;
			{
				std::stringstream sb;
				sb << "Coins " << this->coinsGot;
				lblCoins->setString(sb.str());
			}
			break;
		case kTagSprite2:
			log("No Coin!");
			break;
		case kTagSprite5:
			this->restartScene();
			break;
		default:
			break;
		}
		return true;
	}*/
	return false;
} /* onTouchBegan() */

void HelloWorld::onTouchMoved(Touch* touch, Event* event)
{
	//Todo
}

void HelloWorld::onTouchEnded(Touch* touch, Event* event)
{
	//Todo
}

/*void HelloWorld::restartScene()
{
	auto scene = HelloWorld::createScene();
	Director::getInstance()->replaceScene(scene);
}*/